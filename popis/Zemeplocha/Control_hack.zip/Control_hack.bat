@echo off
:start
cls
title All Shortcuts
echo Welcome,
echo Choose an option from a below list.
echo 1. Uninstall a program
echo 2. Open control panel
echo 3. Open networking control panel
echo 4. Google search
echo 5. Facebook
echo 6. Gmail
echo 7. Twitter
echo 8. Open My computer
 
echo enter your choice
 
set /p choice=
 
if %choice%==1 (
start appwiz.cpl
)
if %choice%==2 (
start control
)
if %choice%==3 (
start ncpa.cpl
)
if %choice%==4 (
start http://www.google.com
)
if %choice%==5 (
start http://www.facebook.com
)
if %choice%==6 (
start http://www.gmail.com
)
if %choice%==7 (
start http://www.twitter.com
)
if %choice%==8 (
start explorer.exe
)  
 
goto start: